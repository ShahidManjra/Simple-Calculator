package com.company;
import java.util.*;
import java.util.Scanner;
public class Main {

    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static void main(String[] args) {

        Scanner inp= new Scanner(System.in);

        double number1;
        double number2;
        double Result;


        System.out.println("Please enter your first number:");

        number1 = inp.nextDouble();

        System.out.println("\nPlease enter your second number:");

        number2 = inp.nextDouble();

        System.out.println("\nPlease select your calculation operator:" + "\n+ for Addition" + "\n- for Subtraction" + "\n* for Multiplication" + "\n/ for Division");

        String operator;

        operator = inp.next();

                switch (operator){
                    case "+":
                        Result = number1 + number2;
                        break;
                    case "-":
                        Result = number1 - number2;
                        break;
                    case "*":
                        Result = number1 * number2;
                        break;
                    case "/":
                        Result = number1 / number2;
                        break;
                    default:
                        System.out.println(ANSI_RED + "\nYou have entered a invalid operator!");
                    return;

                }

        System.out.println( ANSI_GREEN + "\nResult:" + ("\r\n" + ANSI_RESET + number1 + " " + operator + " " + number2 + " = " + Result));
            }

    }

